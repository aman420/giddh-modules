package com.walkover.user.api.exception;

/**
 *
 * @author Gaurav Mahawar
 * @version v1
 * @since 13 Dec 2017
 * 
 */
public class NotFoundException extends Exception {
  
  public NotFoundException(String message) {
    super(message);
  }
  
}
