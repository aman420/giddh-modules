package com.walkover.user.api.exception;

/**
 *
 * @author Gaurav Mahawar
 * @version v1
 * @since 13 Dec 2017
 *
 */
public class UnAuthorizeException extends Exception {

  public UnAuthorizeException(String message) {
    super(message);
  }

}
