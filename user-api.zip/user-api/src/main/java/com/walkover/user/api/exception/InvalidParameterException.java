package com.walkover.user.api.exception;

/**
 *
 * @author Gaurav Mahawar
 * @version v1
 * @since 05 Jan 2018
 * 
 */
public class InvalidParameterException extends Exception {
  
  public InvalidParameterException(String message) {
    super(message);
  }
}
