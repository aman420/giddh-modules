/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.walkover.user.api.services.v1;

import java.util.Optional;
import java.util.List;
import com.walkover.user.api.dao.model.User;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import com.walkover.user.api.dao.repository.UserRepository;
import com.walkover.user.api.resources.v1.UserResources;

/**
 *
 * @author Aman
 */
@Service
public class UserService {
    private final UserRepository userRepository;
  
  @Autowired
  public UserService(UserRepository userRepository) {
    this.userRepository = userRepository;
  }
  
  @Transactional(rollbackFor = {Throwable.class})
  public User saveUser(User user) {
    return userRepository.save(user);
  }
  
  @Transactional
  public void deleteUser(User user){
      userRepository.delete(user);
  }
   @Transactional
   public Optional<User> findUser(String email)
   {
      return userRepository.findByEmailId(email);
   }
   @Transactional
   public List<User> findAllUser()
   {
       return (List)userRepository.findAll();
   }
  
  public boolean doesEmailIdExist(String emailId) {
    return userRepository.doesEmailIdExist(emailId);
  }
  public User updateUser(User user)
  {
      User user1=findUser(user.getEmailId()).get();
        deleteUser(user1);
        user1.setName(user.getName());
        saveUser(user1); 
        return user1;
  }
    
}
