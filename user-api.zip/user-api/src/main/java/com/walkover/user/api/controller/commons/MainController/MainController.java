
package com.walkover.user.api.controller.commons.MainController;
import com.walkover.user.api.models.commens.ApiResponse;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;

import static com.walkover.user.api.models.commens.ApiStatus.success;
import static org.springframework.web.bind.annotation.RequestMethod.GET;

/**
 *
 * @author aman
 */
@Controller
@RequestMapping("/")
public class MainController {

    @RequestMapping(method = GET)
    public ResponseEntity<ApiResponse> welcome() {
        return new ResponseEntity<>(new ApiResponse("Welcome to user-api!", success), HttpStatus.OK);
    }

}

