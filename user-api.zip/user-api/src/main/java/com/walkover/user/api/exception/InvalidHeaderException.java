package com.walkover.user.api.exception;

/**
 *
 * @author Gaurav Mahawar
 * @version v1
 * @since 14 Jan 2018
 * 
 */
public class InvalidHeaderException extends Exception {
  
  public InvalidHeaderException(String message) {
    super(message);
  }
}
