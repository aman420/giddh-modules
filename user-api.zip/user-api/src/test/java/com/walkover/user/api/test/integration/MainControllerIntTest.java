/*package com.walkover.user.api.test.integration;
//import com.walkover.user.api.controller.commons.MainController;
import com.walkover.user.api.controller.UserController;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.test.context.web.WebAppConfiguration;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.result.MockMvcResultMatchers;
import org.springframework.test.web.servlet.setup.MockMvcBuilders;
import org.springframework.transaction.annotation.Transactional;
import com.walkover.user.api.dao.model.User;
import com.walkover.user.api.utils.commens.JsonUtils;
import org.springframework.http.MediaType;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.post;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.jsonPath;*/

/**
 *
 * @author aman
 */
/*@RunWith(SpringJUnit4ClassRunner.class)
@WebAppConfiguration
@ContextConfiguration(
        {
                "classpath:configuration/mvc-dispatcher.xml"
        }
)
@Transactional
public class MainControllerIntTest {
     @Autowired
    private UserController usercontroller;

    private MockMvc mockMvc;

    @Before
    public void setup() {
        this.mockMvc = MockMvcBuilders.standaloneSetup(usercontroller).build();
    }

    @Test
    public void shouldcreateUser() throws Exception {
        User user=new User();
        user.setName(user.getName());
        user.setEmailId(user.getEmailId());
        user.setId(new Long(101));

        String API = "/";
        mockMvc.perform(get(API));
            
                 mockMvc.perform(post(API).contentType(MediaType.APPLICATION_JSON)
                .requestAttr("principal", user)
                .content(JsonUtils.toJson(user)))
                .andExpect(MockMvcResultMatchers.status().isCreated())
                .andExpect(jsonPath("$.status").value("success"))
                .andExpect(jsonPath("$.body.name").value(user.getName()))
                .andReturn();

    }

}*/
